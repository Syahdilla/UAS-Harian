package com.example.syahdillaapplication;

public class Maska {

    String maskapai;
    String eta;
    String des;
    String arrtime;
    String deptime;
    String price;
    String bagasi;

    public Maska() {
    }

    public Maska(String maskapai, String eta, String des, String arrtime, String deptime, String price, String bagasi) {
        this.maskapai = maskapai;
        this.eta = eta;
        this.des = des;
        this.arrtime = arrtime;
        this.deptime = deptime;
        this.price = price;
        this.bagasi = bagasi;
    }

    public String getMaskapai() {
        return maskapai;
    }

    public void setMaskapai(String maskapai) {
        this.maskapai = maskapai;
    }
    //TODO 2: Generate Getter n Setter untuk variabel Maska
}
